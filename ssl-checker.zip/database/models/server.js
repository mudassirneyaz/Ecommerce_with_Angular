const { SERVER_MODEL_NAME } = require('../../constant/dbModelName');
module.exports = (sequelize, DataTypes) => {
	const schema = {
		id: {
			type: DataTypes.UUID,
			primaryKey: true,
			defaultValue: DataTypes.UUIDV4,
			allowNull: false,
		},
		name: {
			type: DataTypes.STRING,
			allowNull: false,
            unique: true
		},
		url: {
			type: DataTypes.STRING,
			allowNull: false,
            unique: true
		},
		port: DataTypes.INTEGER
	};
	const paranoidJson = {
		paranoid: true,
		indexes: [
			{
				unique: true,
				fields: ['name', 'url'],
			},
		],
	};
	return sequelize.define(SERVER_MODEL_NAME, schema, paranoidJson);
};
