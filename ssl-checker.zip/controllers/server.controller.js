const { create, getAll } = require('../dao/server.dao');
const { handleSuccessResponse } = require('../helper/responseHandler');
const { sslChecker } = require('../helper/sslChecker');
const createServer = async (req, res, next) => {
	try {
		const { name, url, port } = req.body;
		const insert = await create({ name, url, port });
		handleSuccessResponse(res, insert, 'Url added successful');
	} catch (err) {
		next(err);
	}
};

const getAllUrl = async (req, res, next) => {
	try {
		const certs = await getAll();
		handleSuccessResponse(res, certs, 'Url added successful');
	} catch (err) {
		console.log('🚀 ~ file: server.controller.js ~ line 10 ~ createServer ~ err', err);
		next(err);
	}
};
const getCertsByUrl = async (req, res, next) => {
	try {
		const { url } = req.params;
		const data = await sslChecker(url);
		const certs = [];
		data.forEach(cert => {
			certs.push({
				subject: cert.subject,
				issuer: cert.issuer,
				validFrom: cert.valid_from,
				validTo: cert.valid_to,
			});
		});
		handleSuccessResponse(res, certs, '');
	} catch (err) {
		next(err);
	}
};

module.exports = {
	createServer,
	getAllUrl,
	getCertsByUrl,
};
