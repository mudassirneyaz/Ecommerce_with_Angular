module.exports = {
	USER_MODEL_NAME: 'user',
	SERVER_MODEL_NAME: 'server',
};
