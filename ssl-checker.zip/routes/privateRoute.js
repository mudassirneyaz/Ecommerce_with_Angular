/*
Note:This all apis is private... need authorization for admin or user
*/
const express = require('express');
const router = express.Router();
const ServerController = require('../controllers/server.controller');

router.post('/add-url',ServerController.createServer);
router.get('/add-url',ServerController.getAllUrl);
router.get('/cert/:url',ServerController.getCertsByUrl);

module.exports = router;
