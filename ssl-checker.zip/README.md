# Node-express-sequelize-boilerplate

## A complete boilerplate(code structure) for nodejs application(backend)

In this code structure, i have use sequelize ORM.

### To start or run the application

1. Setup the enviroment file i.e., dot-env(.env) file
2. Put all your database credentials in the above file

---

### Run the following command in the terminal

1. > `yarn install or yarn`
2. > `yarn start or nodemon`
