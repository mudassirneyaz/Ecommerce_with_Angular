const Server = require('../database/db').server;

const create = data => Server.create(data);
const getAll = () => Server.findAll();

module.exports = {
	create,
    getAll
};
