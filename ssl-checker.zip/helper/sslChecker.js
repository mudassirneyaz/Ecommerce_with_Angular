const https = require('https');
exports.sslChecker = url => {
	return new Promise((resolve, reject) => {
		const options = {
			host: 'angular.io',
			port: 443,
			method: 'GET',
		};

		const request = https.request(options, function (res) {
			let cert = res.connection.getPeerCertificate(true);
			let list = new Set();
			do {
				list.add(cert);
				// console.log('subject', cert.subject);
				// console.log('issuer', cert.issuer);
				// console.log('valid_from', cert.valid_from);
				// console.log('valid_to', cert.valid_to);
				cert = cert.issuerCertificate;
			} while (cert && typeof cert === 'object' && !list.has(cert));
			res.on('error', err => {
				reject(err);
			});
			res.on('data', data => {
				// console.log(data);
				// console.log(list)
			});
			res.on('end', () => {
				resolve(list);
				// console.log('list of certificate', list);
			});
		});
		request.end();
	});
};
